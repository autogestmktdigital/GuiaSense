import { Router } from "express";
import { requireAuth, AuthRequest } from "../../middleware/auth";
import * as insightsService from "./insights.service";
import {
  ensureMonthClosing,
  getVigentMonthClosing,
} from "../monthClosing/monthClosing.service";

const router = Router();

router.use(requireAuth);

router.get("/", async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  await ensureMonthClosing(userId);
  const [insights, closing] = await Promise.all([
    insightsService.getInsights(userId),
    getVigentMonthClosing(userId),
  ]);
  const all = closing ? [closing, ...insights] : insights;
  if (all.length === 0) {
    all.push({
      title: "Tudo certo por enquanto! 😊",
      message: "Quando houver algo importante nas suas finanças, o GuiaSense vai avisar você por aqui.",
      tone: "neutral",
    });
  }
  res.json({ insights: all });
});

export default router;
